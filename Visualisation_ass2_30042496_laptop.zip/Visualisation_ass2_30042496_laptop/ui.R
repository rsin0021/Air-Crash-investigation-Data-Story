#Loading required Libraries

library(shiny)            
library(shinydashboard)
library(plotly)
library(ggplot2)
library(gridExtra)
library(data.table)
library(maps)
library(mapproj)
library(rgdal)
library(leaflet)
gpclibPermit()
library(maptools)
library(RColorBrewer)
library(ggmap)
library(ColorPalette)
library(htmltools)
library(tidyverse)
library("SnowballC")
library(tm)
library(wordcloud)
library(memoise)
library(dplyr)
library(collapsibleTree)


# Define UI for application, i.e implementing layout of shiny dashboard.

ui <- dashboardPage(
    dashboardHeader(title = 'Aircrash Data'),
    dashboardSidebar( #designing the dashboard's sidebar menu
      sidebarMenu(
      menuItem("Home",tabName = 'Home'),
      menuItem("Crash Trends",icon=icon("dashboard")),
        menuSubItem('Crashes Since 1908',tabName = 'Crash'),
        menuSubItem('Crashes by operators',tabName = 'Operators'),
      menuItem("Fatalities",tabName = 'Fatalities',icon=icon("skull")),
      menuItem("Investigate the Crash Causes",tabName = 'Causes',icon=icon("rocket"))
      
    )),
    dashboardBody(  #defining tabs in dashboard
      tabItems(
        
        tabItem(tabName = "Home",
                
                fluidRow(box(width=100,h3('Air Crash Investigation'),align = "center")
                         ),
                         
                
                fluidRow(
                  infoBox("Passengers aboard Since 1908",144551,icon=icon('rocket')),
                  
                  infoBox("Crashes Since 1908",5268,icon=icon('skull')),
    
                  infoBox("Fatalities Since 1908",103523,icon=icon('skull')),
                  
                  
  
                  
                  box(height=420,h2('About the Application'),h4(p("This interactive application provides analysis 
                of the aircraft crashes that occurred over a span of 100 years, i.e from 
                1908 to 2009.The application enables the user to interact with the data and find out the 
                causes for the top 5 countries with most crashes . ",
                        style = "font-family: 'times'; style = font-size:20px")),
                      tags$img(src='giphy.gif',height=275,width=500)),
                  
                  box(plotlyOutput('country_crashes'))
                  
                  
                
                )
                
                
                
                
                
        ),
        
        tabItem(tabName = "Crash",
        fluidRow(h2('Yearly Crashes',align='center'),
                 
                 h4(p("Lets first visualise the number of crashes occured over the world
                          since 1908.  You can choose your own time period using the slider
                          control given below.", style = "font-family: 'times'; style = font-size:20px")),
  
                 
          box(width = '100',plotlyOutput("lineplot"),solidHeader = T,sliderInput("timeline","Choose Your Timeline",
                                                 min=1908, max=2009,
                                                 value = c(1908,2009),
                                                 dragRange = TRUE)))
      ),
      tabItem(tabName = "Fatalities",
              fluidRow(
                h2('Percentage Distribution of Crash Fatalities Worldwide',align='center'),
                
                h4(p("As we saw on the home page, USA and Russia have the most number of crashes since 1908.
                      The choropleth map below shows the worldwide percentage distribution of crash fatalities,
                      and displays the year of maximum crashes  and the number of fatalities in that year for each country.
                     Hover to find out.", style = "font-family: 'times'; style = font-size:20px")),
                box(width=100,leafletOutput("map"),align='center')
              )
              
      ),
      
      tabItem(tabName = "Causes",
              fluidRow(
                
                box(width=100,h2('Investigation of Causes'),align='center'),
                h4(p("By now we have analysed several aspects of the aircrash data.This feature will 
                     let you find out the causes of air crashes for the top 5 countries and across the world.
                     You can explore the causes by varying the frequency and number of words
                     for each country with the slider control given on the side. ", style = "font-family: 'times'; style = font-size:20px")),
                column(8,plotOutput("plot"),solidHeader = T,align='left'),
                column(3,
                    selectInput("selection", "Choose the Country to investigate:",choices = countries),
                    actionButton("update", "Change"),
                    hr(),
                    sliderInput("freq",
                                "Minimum Frequency:",
                                min = 1,  max = 50, value = 15),
                    sliderInput("max",
                                "Maximum Number of Words:",
                                min = 1,  max = 300,  value = 100))
                
                )
                
                
                
              
              
              
          ),
      
      tabItem(tabName = "Operators",
              fluidRow(
                h2('Crashes by Top 10 Worst Operators',align='center'),
                h4(p("Here's the list of top 10 most unsafe airline operators with the number of crashes
                      by each operator since 1908. Click each node to explore and choose wisely who you want to travel with.", style = "font-family: 'times'; style = font-size:20px")),
                box(width=10,collapsibleTreeOutput("mytree"),solidHeader = T)
              )
              
      )
      
        
      )
    )
  )

