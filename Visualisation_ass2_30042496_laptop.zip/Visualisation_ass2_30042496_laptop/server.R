#Loading required Libraries

library(shiny)            
library(shinydashboard)
library(plotly)
library(ggplot2)
library(gridExtra)
library(data.table)
library(maps)
library(mapproj)
library(rgdal)
library(leaflet)
gpclibPermit()
library(maptools)
library(RColorBrewer)
library(ggmap)
library(ColorPalette)
library(htmltools)
library(tidyverse)
library("SnowballC")
library(tm)
library(wordcloud)
library(memoise)
library(dplyr)
library(collapsibleTree)

#Fetching data from csv

crash<-read.csv('Airplane_Crashes_and_Fatalities_Since_1908_cleaned.csv', header = TRUE, sep = ",")
data <- read.csv("Fatalities_percentbycountry.csv")
yearly_trend <- as.data.frame(table(crash$Year))
setnames(yearly_trend, old=c("Var1","Freq"), new=c("Year_of_Crash", "Number_of_Crashes"))


# The list of valid countries for word cloud

countries <<- list("Across the World" = "world",
               "United States of America" = "usa",
               "Russia" = "russia",
               "Brazil"="brazil",
               "Canada"="canada",
               "Colombia"="colombia")

# Using "memoise" to automatically cache the results

getTermMatrix <- memoise(function(country) {
  
  if (!(country %in% countries))
    stop("Unknown country")
  
  text <- readLines(sprintf("%s.txt", country),
                    encoding="UTF-8")
  
  myCorpus = Corpus(VectorSource(text))
  myCorpus = tm_map(myCorpus, content_transformer(tolower))
  myCorpus = tm_map(myCorpus, removePunctuation)
  myCorpus = tm_map(myCorpus, removeNumbers)
  myCorpus = tm_map(myCorpus, removeWords,
                    c(stopwords("SMART"), "to", "airplane",'crashed', "Not Reported", "the", "and", "Summary"))
  
  myDTM = TermDocumentMatrix(myCorpus,
                             control = list(minWordLength = 1))
  
  m = as.matrix(myDTM)
  
  sort(rowSums(m), decreasing = TRUE)
})


# Making plots for data

shinyServer(function(input, output,session) {
  
#Code for Home Page
  output$country_crashes<-renderPlotly({
    
    x <- c('United States', 'Russia', 'Brazil','Canada','Colombia','France','United Kingdom','India','Germany','Indonesia')
    y <- c(1348,238,187,154,148,131,113,100,90,87)
    text <- c('1348 Crashes','238 Crashes','187 Crashes','154 Crashes','148 Crashes','131 Crashes','113 Crashes','100 Crashes','90 Crashes','87 Crashes')
    data <- data.frame(x, y, text,stringsAsFactors = FALSE)
    data$x<-factor(data$x,levels=unique(data$x)[order(data$y,decreasing = TRUE)])
    p <- plot_ly(data, x = ~x, y = ~y, type = 'bar',
                 text = y, textposition = 'auto',
                 marker = list(color = 'rgb(158,202,225)',
                               line = list(color = 'rgb(8,48,107)', width = 1.5))) %>%
      layout(title = "Top 10 Countries with most crashes since 1908",
             xaxis = list(title = "Number of Crashes"),
             yaxis = list(title = "Countries"))
    p
    
  })
  
#Code for crash trend plot  
  
  output$lineplot<-renderPlotly({
    
    timeline <- seq(input$timeline[1], input$timeline[2])
    f1_new <- yearly_trend[which(yearly_trend$Year_of_Crash %in% timeline),]
    # p1 <- ggplot(data = f1_new, aes(x = Lap, y = Lap.Time, colour = Driver))
      vary<-ggplot(f1_new , aes(x = Year_of_Crash,y = Number_of_Crashes,group=1))

      vary+ geom_line(size = 1, linetype = 1, color = "Navy") + 
      geom_point(size = 2, shape = 20)+ 
      geom_smooth() +
      xlab("Years") + ylab("Crashes") +
      scale_x_discrete(breaks = seq(from = 1908, to = 2009, by = 30)) + 
      ggtitle(" ")
    
  })
  
  #Code for Choropleth map for Fatalities Tab
  
  output$map<-renderLeaflet({
    
    world_map <- readOGR("ne_50m_admin_0_countries.shp")
    data <- read.csv("Fatalities_percentbycountry.csv")
    rates <- data$Fatalties_percentage[match(world_map$admin, data$Country)]
    rates1 <- data$Year[match(world_map$admin, data$Country)]
    rates2 <- data$Fatalities[match(world_map$admin, data$Country)]
    qpal <- colorNumeric(
      palette = "YlOrRd",
      domain = rates)
    
    labels <- sprintf("<strong>%s</strong><br/> Fatalities Occured: %g %% <br/> 
                      Max Fatalities Year: %g <br/> No. of Fatalities Occured in %g : %g",
                      world_map$admin,rates,rates1,rates1,rates2)%>% lapply(htmltools::HTML)
      
    leaflet(world_map) %>% setView(zoom = 1,lng = 44.63, lat = 28.77) %>% # create a blank canvas
      addTiles() %>% # add tile
      ## addCircleMarkers(~data$Country, ~data$Fatalties_percentage, color = ~xpal(rates), group = "circles") %>%
      addPolygons( # draw polygons on top of the base map (tile)
        stroke = FALSE, 
        smoothFactor = 0.2, 
        fillOpacity = 0.7,
        color = ~qpal(rates),
        highlight = highlightOptions(
          weight = 5,
          color = "#666",
          fillOpacity = 1,
          bringToFront = TRUE,
          box(width=100)
         ),
        label=labels,
        labelOptions = labelOptions(
          style = list("font-weight" = "normal", padding = "3px 8px"),
          textsize = "15px",
          direction = "auto")
      )%>%
      addLegend("bottomleft", pal = qpal, values = ~rates,
                title = " ",
                labFormat = labelFormat(suffix = "%"),
                opacity = 0.9)
    
    

    
    
  })
  
  #Code for Word Cloud
  
  # Define a reactive expression for the document term matrix
  terms <- reactive({
  # Change when the "change" button is pressed...
    input$update

    isolate({
      withProgress({
        setProgress(message = "Processing corpus...")
        getTermMatrix(input$selection)
      })
    })
  })
  
  # Make the wordcloud 
  wordcloud_rep <- repeatable(wordcloud)
  
  output$plot <- renderPlot({
    v <- terms()
    wordcloud_rep(names(v), v, scale=c(4,0.5),
                  min.freq = input$freq, max.words=input$max,
                  colors=brewer.pal(8, "Dark2"))
  })
  
  #Code for Collapsible Tree
  
  output$mytree <- renderCollapsibleTree({

    operators<-read.csv("operator_data.csv")

    collapsibleTreeSummary(
      operators,
      hierarchy = c("Operator", "Number_of_Crashes"),
      nodeSize="Number_of_Crashes",
      width = 100,
      zoomable = FALSE
    )

  })
    
    
  
})